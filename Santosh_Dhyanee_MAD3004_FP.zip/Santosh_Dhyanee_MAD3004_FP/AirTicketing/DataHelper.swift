//
//  DataHelper.swift
//  Shopping
//
//  Created by Jigisha Patel on 2018-07-19.
//  Copyright © 2018 JK. All rights reserved.
//

import Foundation
class DataHelper{
    var ProductList = [Int : Product]()
    var CustomerList = [String : Customer]()
    
    init(){
        self.loadProductsData()
        self.loadCustomersData()
    }
    
    func loadProductsData(){
        ProductList = [:]
        
        do{
            
        let YYZ = try Product(productID: 001, productName: "Emiraties", manufecturer: "YYZ - LHR", unitPrice: 1000.1, category: ProductCategory.Airbus)
            ProductList[(YYZ.ProductID!)] = YYZ
        
        let LHR = try Product(productID: 101, productName: "Air canada", manufecturer: "MUM - LHR", unitPrice: 912.23, category: ProductCategory.Bioweing)
            ProductList[(LHR.ProductID!)] = LHR
        
        let MUM = try Product(productID: 100, productName: "jet airways", manufecturer: "mum - RAJ", unitPrice: 920, category: ProductCategory.Bioweing)
            ProductList[(MUM.ProductID!)] = MUM
        
        let HYD = try Product(productID: 020, productName: "Lufthanza", manufecturer: "HYD - TIR", unitPrice: 927.97, category: ProductCategory.Airbus)
            ProductList[(HYD.ProductID!)] = HYD
        
        let MAA = try Product(productID: 102, productName: "spice jet", manufecturer: "LMD - MAA", unitPrice: 911.89, category: ProductCategory.Airbus)
            ProductList[(MAA.ProductID!)] = MAA
      
        }catch{
            print("Error: \(error)")
        }
    }
    
    func displayProducts(){
        print("Flight Details")
        Util.drawLine()
        print("\t Flight ID \t\t Flight Name \t\t\t\t  \t\t Category \t\t Unit Price")
        for (_, value) in self.ProductList.sorted(by: { $0.key < $1.key }){
            Util.drawLine()
            print("\t \(value.ProductID!) : \(value.ProductName!) : \(value.Manufecturer!) : \(value.Category!) : \(value.UnitPrice!)")
        }
        Util.drawLine()
    }
    
    func searchProduct(productID : Int) -> Product?{
        if ProductList[productID] != nil{
            return ProductList[productID]! as Product
        }
        else{
            print("Sorry..The flight ID you have entered is not available")
            return nil
        }
    }
    
    func loadCustomersData(){
        CustomerList = [:]
//
//        let Param = Customer(customerID: "C101", customerName: "Paramjeet", email: "param@mad.com", address: "114 Michigan Ave. Brampton", creditCardInfo: "4520-0100-1234-5678", shippingInfo: "Ship to lambton college between 08:00 AM to 12:00 PM")
//        CustomerList[Param.CustomerID!] = Param
//
//        let Santosh = Customer(customerID: "C102", customerName: "Santosh", email: "Santosh@mad.com", address: "54 Marjary Ave. DownTown. Toronto", creditCardInfo: "4520-0100-6543-8976", shippingInfo: "Deliver at Papa John's at 03PM")
//        CustomerList[Santosh.CustomerID!] = Santosh
    }
    
    func displayCustomers(){
        for (_, value) in self.CustomerList.sorted(by: { $0.key < $1.key }){
            Util.drawLine()
            print(value.displayData())
        }
        Util.drawLine()
    }
}
