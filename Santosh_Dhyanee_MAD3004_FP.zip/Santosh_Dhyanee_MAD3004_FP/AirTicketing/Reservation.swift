//
//  Order.swift
//  Shopping
//
//  Created by Jigisha Patel on 2018-07-19.
//  Copyright © 2018 JK. All rights reserved.
//

import Foundation

typealias orderItem = (productID: Int, product: Product,quantity: Int)

class Order: Customer{
    private var orderID : Int
    private var orderDate : Date
    private var orderStatus : OrderStatusList?
    private var orderProducts : [orderItem]
    private var dataHelper = DataHelper()
    
    var OrderID : Int{
        get { return self.orderID }
        set{ self.orderID = newValue}
    }
    var OrderDate : Date{
        get { return self.orderDate }
        set{ self.orderDate = newValue}
    }
    var OrderStatus : OrderStatusList?{
        get { return self.orderStatus ?? OrderStatusList.NoReservation }
        set{ self.orderStatus = newValue}
    }
    
    //computed property
    var orderAmount: Double?{
        get{
            var amount = 0.0
            if !self.orderProducts.isEmpty{
                for (_, prod, qty) in self.orderProducts{
                    amount += prod.UnitPrice! * (Double)(qty)
                }
            }
            return amount
        }
    }
    
    override init(){
        self.orderID = 0
        self.orderDate = DateFormatter().date(from: "")!
        self.orderStatus = OrderStatusList.NoReservation
        self.orderProducts = []
        super.init()
    }
    
    override func displayData() -> String {
        var returnData = ""

        returnData += "\n Flight ID : \(self.OrderID)"
        returnData += "\n reservation  Date : \(self.OrderDate )"
//        returnData += super.displayData()
        returnData += "\n Products List : "
        if !self.orderProducts.isEmpty{
            for (_, product, qty) in self.orderProducts{
                returnData += "\n \tFlight : \(product.displayData())"
                returnData += "\n \tNumber of seats : \(qty)"
            }
        }else{
            returnData += "\n No  reservations made"
        }
        returnData += "\n reservation status  Status : \(self.OrderStatus ?? OrderStatusList.NoReservation)"
        returnData += "\n reservation Amount : \(self.orderAmount  ?? 0.0)"
        
        return returnData
    }
    
    func addOrder(){
        dataHelper.displayProducts()
        print("Please enter Flight ID to choose the flight from the list : ")
        let selectedProductID : Int = (Int)(readLine()!)!
        
        if let selectedProduct = dataHelper.searchProduct(productID: selectedProductID){
            self.OrderID = selectedProductID
            self.OrderDate = Date()
            
            print("How many Seats do you want to reserve  ? : ")
            let qty : Int = (Int)(readLine()!) ?? 1
            
            self.orderProducts += [(productID: selectedProductID, product: selectedProduct, quantity: qty)]
            self.OrderStatus = OrderStatusList.Reserved
             print("Review your reservarion \n \(self.displayData())")
            
        }else{
            print("Sorry...The Flight ID you entered is unavailable")
        }
    }
    
    func cancelOrder(){
        if !orderProducts.isEmpty {
            print("Review your reservarion \n \(self.displayData())")
            
            print("Please enter Flight ID to remove from the Reservation : ")
            let selectedProductID : Int = (Int)(readLine()!)!
            var productIndex = -1

            for (index, item) in self.orderProducts.enumerated(){
                if (item.productID == selectedProductID){
                    productIndex = index
                }
            }
            
            if productIndex != -1{
                self.orderProducts.remove(at: productIndex)
                print("The Flight is removed from your Reservation")
            }
        }else{
            print("You have no Reservations")
        }
    }
}
