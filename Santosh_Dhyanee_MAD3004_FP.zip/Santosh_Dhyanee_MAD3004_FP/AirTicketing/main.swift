//
//  main.swift
//  AirTicketing
//
//  Created by MacStudent on 2018-07-30.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
func pass()
{
    var choice = 1
    let dataHelper = DataHelper()
    var order = Order()
    
    while choice != 6{
        print("\n----Welcome to Air ticketing !----")
        print("\t 1 : Enquiry ")
        print("\t 2 : make a Reservation ")
        print("\t 3 : Show Reservations ")
        print("\t 4 : Update reservation ")
        print("\t 5 : Cancel Reservation")
        print("\t 6 : Exit ")
        print("-----------------------------------------")
        print("Enter you choice please : ")
        choice = (Int)(readLine()!)!
        
        switch choice{
        case 1:
            print("Please enter any query of yours , we will get back to you")
            pass()
        case 2:
            order.addOrder()
        case 3:
            print(order.displayData())
            //    case 4:
        //        order.updateOrder()
        case 5:
            order.cancelOrder()
        case 6:
            exit(0)
        default:
            print("Please enter valid menu option.")
        }
        
    }
}
var choice = 1
while choice != 3
{
   print("Please select the option you prefer:  ")
   print("Enter 1 - Admin")
   print("Enter 2 - Passenger")
   print("Enter 3 - Exit")
   choice = (Int)(readLine()!) ?? 1
    
    switch choice
        
    {
        
    case 1:
        
        print("Admin selected!")
        
    case 2:
        
        pass()
        
    case 3:
        
        exit(0)
        
    default:
        
        print("Invalid option selected, try again.")
        
    }
    
}


