//
//  Employees.swift
//  AirTicketReservation
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Employees  {
    
    var employeeId : String?
    var EmployeeName : String?
    var EmployeeEmail : String?
     var EmployeeMobile : String?
     var EmployeeAddress : String?
     var EmployeeDesignation : String?
     var EmployeeSin : String?
    
    
    
}
