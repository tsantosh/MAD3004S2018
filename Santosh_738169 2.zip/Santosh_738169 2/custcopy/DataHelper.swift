//
//  DataHelper.swift
//  Shopping
//
//  Created by Jigisha Patel on 2018-07-19.
//  Copyright © 2018 JK. All rights reserved.
//

import Foundation
class DataHelper{
    var ProductList = [Int : Product]()
    var CustomerList = [String : Customer]()
    
    init(){
        self.loadProductsData()
        self.loadCustomersData()
    }
    
    func loadProductsData(){
        ProductList = [:]
        
        do{
            
        let Book1 = try Product(productID: 111, productName: "Unbroken", manufecturer: "Laura Hillenbrand", unitPrice: 1.25, category: ProductCategory.Biography)
            ProductList[(Book1.ProductID!)] = Book1
        
        let Book2 = try Product(productID: 112, productName: "The Cellar", manufecturer: "Natasha Preston", unitPrice: 2, category: ProductCategory.Drama)
            ProductList[(Book2.ProductID!)] = Book2
        
        let Book3 = try Product(productID: 113, productName: "Spilled Milk", manufecturer: "KLR", unitPrice: 1.50, category: ProductCategory.Fiction)
            ProductList[(Book3.ProductID!)] = Book3
        
        let Book4 = try Product(productID: 114, productName: "The Legend of Zelda", manufecturer: "JK Rowling", unitPrice: 2.50, category: ProductCategory.Romance)
            ProductList[(Book4.ProductID!)] = Book4
        
        let Book5 = try Product(productID: 115, productName: "Harry Potter", manufecturer: "Debbie Macober", unitPrice: 4.20, category: ProductCategory.Romance)
            ProductList[(Book5.ProductID!)] = Book5
        
        let Book6 = try Product(productID: 116, productName: "Cottage by the Sea", manufecturer: "Shakeshphere", unitPrice: 1.90, category: ProductCategory.Biography)
            ProductList[(Book6.ProductID!)] = Book6
        
        let Book7 = try Product(productID: 117, productName: "Wake me up", manufecturer: "Rajad", unitPrice: 1.35, category: ProductCategory.Biography)
            ProductList[(Book7.ProductID!)] = Book7
        }
        catch{
            print("Error: \(error)")
        }
    }
    
    func displayProducts(){
        print("Book Details")
        Util.drawLine()
        print("\t ID \t\t Book title \t\t\t\t Author \t\t Category \t\t RefundablePrice")
        for (_, value) in self.ProductList.sorted(by: { $0.key < $1.key }){
            Util.drawLine()
            print("\t \(value.ProductID!) ------ \(value.ProductName!) ------ \(value.Manufecturer!) ------ \(value.Category!) ------ \(value.UnitPrice!)")
        }
        Util.drawLine()
    }
    
    func searchProduct(productID : Int) -> Product?{
        if ProductList[productID] != nil{
            return ProductList[productID]! as Product
        }
        else{
            print("Sorry..The book ID you have entered is not available")
            return nil
        }
    }
    
    func loadCustomersData(){
        CustomerList = [:]
        
        let Param = Customer(customerID: "0101", customerName: "Santosh", email: "santoshonthemove.com", address: "114 Michigan Ave. Brampton", contactinfo: "416-0128759", password: "4747")
        CustomerList[Param.CustomerID!] = Param
        
        let Santosh = Customer(customerID: "C102", customerName: "Santosh", email: "Santosh@mad.com", address: "54 Marjary Ave. DownTown. Toronto", contactinfo: "416-816-6016", password: "123456")
        
        CustomerList[Santosh.CustomerID!] = Santosh
    }
    
    func verifyLogin() {
        
    }
    
    func displayCustomers(){
        for (_, value) in self.CustomerList.sorted(by: { $0.key < $1.key }){
            Util.drawLine()
            print(value.displayData())
        }
        Util.drawLine()
    }
}
