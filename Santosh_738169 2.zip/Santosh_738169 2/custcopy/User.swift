//
//  Customer.swift
//  Shopping
//
//  Created by Jigisha Patel on 2018-07-19.
//  Copyright © 2018 JK. All rights reserved.
//

import Foundation

class Customer : IDisplay{
    var customerID : String?
    private var customerName : String?
    private var address : String?
    private var email : String?
    private var password : String?
      private var contactinfo : String?
  
    
    //stored property
    var CustomerID : String?{
        get{ return self.customerID }
        set{ self.customerID = newValue }
    }
    
    var CustomerName : String?{
        get{ return self.customerName }
        set{ self.customerName = newValue }
    }
    
    var Email : String?{
        get { return self.email}
        set {self.email = newValue}
    }
    var Address : String?{
        get { return self.address}
        set {self.address = newValue}
    }
   
    
//    var contactinfo : String?{
//        get { return self.contactinfo}
//        set {self.contactinfo = newValue}
//    }

    //default initializer / constructor
    init(){
        self.customerID = "1010"
        self.customerName = "santosh"
        self.email = "santoshonthemove@gmail.com"
        self.address = "54, marjory avenue , Downtown ,Toronto "
        self.contactinfo = "4168166016"
        self.password = "123456"
      
    }
    
    //parameterized initializer
    init(customerID: String, customerName : String, email : String, address : String, contactinfo : String, password : String){
        
        self.customerID = customerID
        self.customerName = customerName
        self.email = email
        self.address = address
        self.contactinfo = contactinfo
        self.password = password
    }
    
    func displayData() -> String{
        var returnData = ""

        if self.customerID != nil{
            returnData += " Customer ID : " + self.customerID!
        }
        if self.customerName != nil{
            returnData += "\n Customer Name : " + self.customerName!
        }
        if self.email != nil{
            returnData += "\n Customer Email : " + self.email!
        }
        if self.address != nil{
            returnData += "\n Customer Address : " + self.address!
        }
        if self.contactinfo != nil{
            returnData += "\n Customer Credit Card Info : " + self.contactinfo!
        }
        if self.password != nil{
            returnData += "\n Customer Shipping Info : " + self.password!
        }
        return returnData
    }
    
    
}









