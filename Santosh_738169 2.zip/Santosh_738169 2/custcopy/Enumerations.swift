//
//  Enumerations.swift
//  Shopping
//
//  Created by Jigisha Patel on 2018-07-19.
//  Copyright © 2018 JK. All rights reserved.
//

import Foundation

enum ProductCategory : Int, CaseIterable{
    case Biography = 1
    case Drama = 2
    case Fiction = 3
    case Romance = 4
   // case Thriller = 5
    case None = 5
}

enum OrderStatusList : CaseIterable{
    case Shipped
    case Delivered
    case Cancelled
    case Confirmed
    case Placed
    case InTransit
    case NoOrder
}

enum ProductError: Error, CustomStringConvertible {
    case InvalidProductID
    case InvalidProductPrice(Int)
    
    var description: String {
        switch self {
        case .InvalidProductID:
            return "Invalid book id"
        case .InvalidProductPrice(let productID):
            return "Invalid book price for book  id :: \(productID)"
        }
    }
}


extension CaseIterable where Self: Hashable {
    static var allCases: [Self] {
        return [Self](AnySequence { () -> AnyIterator<Self> in
            var raw = 0
            var first: Self?
            return AnyIterator {
                let current = withUnsafeBytes(of: &raw) { $0.load(as: Self.self) }
                if raw == 0 {
                    first = current
                } else if current == first {
                    return nil
                }
                raw += 1
                return current
            }
        })
    }
}

