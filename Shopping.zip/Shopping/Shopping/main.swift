//
//  main.swift
//  Shopping
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

var Santosh = Customer()
Santosh.customerId = "C101"

print(Santosh.displaydata())


var shashank = Customer(customerId: "c102",customerName: "shashank",address: "54 marjory avenue", email: "Sammy@gmail.com",creditCardInfo: "419-986-6598",ShoppingInfo: "ship to home between 08:00 AM - 12:00PM")


print(shashank.displaydata())


var newuser = Customer()

newuser.registration()
print(newuser.displaydata())

shashank.CustomerName = "rickey"
shashank.ShoppingInformation = "delover home"
print(shashank.displaydata())

Santosh.CustomerName = "Santosh"
Santosh.Email = "Santosh@mad.com"
Santosh.Address = "54 marjory ave . Downtown , toronto"
Santosh.ShoppingInformation = "papa johns"
Santosh.CreditCardInfo = "4586-9986-9986-5524"

print(Santosh.displaydata())

