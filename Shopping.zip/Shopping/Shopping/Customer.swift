//
//  Customer.swift
//  Shopping
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


class Customer {
    
    var customerId: String?
    private var customerName : String?
     private var address : String?
     private var email : String?
     private var creditCardInfo : String?
     private var ShoppingInfo : String?
    
    var CustomerName : String?{
        get {
            
            return self.customerName
        }
        set{
            
            self.customerName = newValue
        }
    }
    var Email : String?{
        get {
            
            return self.email
        }
        set{
            
            self.email = newValue
        }
    }
    var Address : String?{
        get {
            
            return self.address
        }
        set{
            
            self.address = newValue
        }
    }
    var CreditCardInfo : String?{
        get {
            
            return self.creditCardInfo
        }
        set{
            
            self.creditCardInfo = newValue
        }
    }
    
    var ShoppingInformation : String?{
        get {
            
            return self.ShoppingInfo
        }
        set{
            
            self.ShoppingInfo = newValue
        }
    }
    
    //default initializer
    init() {
        self.customerId = ""
         self.customerName = ""
         self.address = ""
         self.email = ""
         self.creditCardInfo = ""
         self.ShoppingInfo = ""
        
    }
    // parameterized initializer
    
    init(customerId: String ,customerName: String,address: String,email: String,creditCardInfo: String,ShoppingInfo: String) {
        
        self.customerId = customerId
        self.customerName = customerName
        self.address = address
        self.email = email
        self.creditCardInfo = creditCardInfo
        self.ShoppingInfo = ShoppingInfo
        
    }
    func displaydata() -> String {
        var returnData = ""
        
        if self.customerId != nil {
            
            returnData += "\n Customerid : " + self.customerId!
            
        }
        
        
        if self.customerName != nil {
            returnData += "\n customerName : " + self.customerName!
            
        }
        if self.address != nil {
            returnData += "\n address : " + self.address!
            
        }
        if self.email != nil {
            returnData += "\n email : " + self.email!
            
        }
        if self.creditCardInfo != nil {
            returnData += "\n creditCardInfo : " + self.creditCardInfo!
            
        }
        if self.ShoppingInfo != nil {
            returnData += "\n ShoppingInfo : " + self.ShoppingInfo!
            
        }
        return returnData
    }
    func registration() {
        print("Enter customer ID:")
        self.customerId = readLine()!
        print("Enter customerName :")
        self.customerName = readLine()!
        print("Enter address:")
        self.address = readLine()!
        print("Enter email:")
        self.email = readLine()!
        print("Enter creditCardInfo:")
        self.creditCardInfo = readLine()!
        print("Enter ShoppingInfo:")
        self.ShoppingInfo = readLine()!
        
    }
}
