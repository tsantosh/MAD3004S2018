//
//  main.swift
//  Day7
//
//  Created by MacStudent on 2018-07-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")



var shivam = PermanenntEmployee ( empID: 101, empName: "shiva", basicPay: 4005.23, holiday: 2)

shivam.display()


var santy = PermanenntEmployee ( empID: 102, empName: "santu", basicPay: 4009.23, holiday: 4)

santy.display()


var kali = PermanenntEmployee (empID: 515, empName: "sadfasntu", basicPay: 009.23, holiday: 4)
kali.display()


print("1 is the prime number ? \(2.isPrime)")
print("3 is the prime number ? \(3.isPrime)")
print("10 is the prime number ? \(10.isPrime)")


print("length of the string \("hello".length)")
5.wish {
    print("happy birday")
}


print("digit at index 1 in number48445681 is \(484546541[1])")
